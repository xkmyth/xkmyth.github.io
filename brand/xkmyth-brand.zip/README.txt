xkmyth 品牌素材（2026）

包含
  logo.svg             主标识（矢量，可无限缩放；深底为设计基准）
  icon-512.png         应用图标 512×512
  icon-192.png         应用图标 192×192
  icon-maskable-512.png  自适应图标（Android maskable，四周留安全边）
  og-1200x630.png      社交分享图
  favicon.png          站点图标 64×64

用法
  1. 深色底上使用金黄色标识，浅色底请用 #b45309 单色版本（可把 logo.svg 的 gradient 换成纯色）。
  2. 标识左右最小留白 = 星形外接圆直径的 1/4。
  3. 允许：链接、截图、评测、教程中引用；不允许：暗示官方背书、改动星形比例、把标识用于自家产品图标。

颜色
  夜蓝 #04060f / #0a1226 · 金色 #fcd34d · 冰蓝 #9ae3ff · 薄荷 #80ffdb · 玫瑰 #ff8fa3
字体
  中文：系统无衬线（PingFang SC / Microsoft YaHei）；英文：系统 sans-serif 与等宽字体
联系
  https://xkmyth.github.io/contact/
